package com.example.aula07_exemplo

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Desafio_06 : AppCompatActivity() {
    lateinit var sharedPreferences: SharedPreferences
    lateinit var selectedItem: String
    val sharedPreferenceName = "MyPrefs"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_desafio06)

        val listView = findViewById<ListView>(R.id.listView)
        val detailTitleTextView = findViewById<TextView>(R.id.detailTitleTextView)
        val detailDescriptionTextView = findViewById<TextView>(R.id.detailDescriptionTextView)
        sharedPreferences = getSharedPreferences(sharedPreferenceName, Context.MODE_PRIVATE)

        // Recupere a lista de itens predefinidos
        val items = resources.getStringArray(R.array.items)

        // Configure o adaptador da ListView
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
        listView.adapter = adapter

        // Defina um ouvinte de clique na ListView
        listView.setOnItemClickListener { _, _, position, _ ->
            // Quando um item é clicado, exiba seus detalhes
            selectedItem = items[position]
            detailTitleTextView.text = "Item selecionado: $selectedItem"
            detailDescriptionTextView.text = "O item $selectedItem é muito interessante e por isso eu cliquei nele"

//            // Armazene o item favorito nas preferências compartilhadas
//            sharedPreferences.edit().putString("favoriteItem", selectedItem).apply()
        }

        // Verifique se há um item favorito nas preferências compartilhadas e exiba-o
        val favoriteItem = sharedPreferences.getString("favoriteItem", "")
        if (favoriteItem != null) {
            if (favoriteItem.isNotEmpty()) {
                detailTitleTextView.text = "Item selecionado: $favoriteItem"
                detailDescriptionTextView.text = "O item $favoriteItem é muito interessante e por isso eu cliquei nele"
            }
        }
    }

    override fun onStop() {
        super.onStop()

        // Armazene o item favorito nas preferências compartilhadas
        sharedPreferences.edit().putString("favoriteItem", selectedItem).apply()
    }
}