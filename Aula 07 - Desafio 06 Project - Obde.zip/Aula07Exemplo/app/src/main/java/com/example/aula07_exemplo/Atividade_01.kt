package com.example.aula07_exemplo

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class Atividade_01 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_atividade01)

        // Inicialize o SharedPreferences com o nome "MyPrefs"
        val sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

        // Referencie os elementos do layout pelo ID
        val nameEditText = findViewById<EditText>(R.id.nameEditText)
        val saveButton = findViewById<Button>(R.id.saveButton)
        val displayTextView = findViewById<TextView>(R.id.displayTextView)

        // Configure o clique do botão para salvar o nome
        saveButton.setOnClickListener {
            // Obtenha o nome inserido pelo usuário
            val userName = nameEditText.text.toString()

            // Salve o nome no SharedPreferences
            val editor = sharedPreferences.edit()
            editor.putString("user_name", userName)
            editor.apply()

            // Atualize o TextView com o nome inserido
            displayTextView.text = "Hello, $userName!"
        }

        // Recupere o nome do usuário do SharedPreferences
        val storedName = sharedPreferences.getString("user_name", "")

        // Se o nome do usuário não estiver armazenado, use um valor padrão
        if (storedName.isNullOrEmpty()) {
            displayTextView.text = "Your Name Will Appear Here"
        } else {
            displayTextView.text = "Hello, $storedName!"
        }
    }
}