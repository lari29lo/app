package com.example.aula07_exemplo

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class ExemploSharedPreferenceActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.exemplo_sharedpreference)

        // Inicialize o SharedPreferences com o nome "MyPrefs"
        val sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

        // Referencie os elementos do layout pelo ID
        val dataEditText = findViewById<EditText>(R.id.dataEditText)
        val saveButton = findViewById<Button>(R.id.saveButton)
        val displayTextView = findViewById<TextView>(R.id.displayTextView)

        // Configure o clique do botão para salvar os dados
        saveButton.setOnClickListener {
            // Obtenha os dados inseridos pelo usuário
            val inputData = dataEditText.text.toString()

            // Salve os dados no SharedPreferences
            val editor = sharedPreferences.edit()
            editor.putString("persisted_data", inputData)
            editor.apply()

            // Atualize o TextView com os dados salvos
            displayTextView.text = "Persisted Data: $inputData"
            dataEditText.text.clear()
        }

        // Recupere os dados do SharedPreferences
        val persistedData = sharedPreferences.getString("persisted_data", "")

        if (!persistedData.isNullOrBlank()) {
            // Preencha o TextView com os dados salvos
            displayTextView.text = "Persisted Data: $persistedData"
        }
    }
}