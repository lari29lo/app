package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //identificar os componentes
        val listaTarefas= findViewById<ListView>(R.id.lista)

        //criar o array (lista) de tarefas
    //   val tarefas = arrayOf ("Preto", "Amarelo", "Azul", "Verde", "Branco")
        val tarefas = resources.getStringArray(R.array.lista)

        //criar o adaptador
        val adaptador = ArrayAdapter(this, android.R.layout.simple_list_item_1, tarefas)

        //conectar o adaptador a lista
        listaTarefas.adapter = adaptador

        // evento de clique
        listaTarefas.setOnItemClickListener { _,_, posicao, _ ->
            val listaSelecionada = tarefas[posicao]
            exibirMensagem(listaSelecionada)
        }
    }
fun exibirMensagem(cor : String){
    val mensagem = "você selecionou a cor: $cor"
    Toast.makeText (this, mensagem, Toast.LENGTH_SHORT).show()
}
}
